import json
import random
import string
import datetime
import boto3
import os
 
def lambda_handler(event, context):
    """
    Generates 200 fictitious cinema POS transaction records and saves them to S3.
    """
    # Replace with your actual S3 bucket name
    bucket_name = os.environ['bucket_name']
   
    # We'll generate a unique file name using the current timestamp
    object_key = f"inventory-{int(datetime.datetime.now().timestamp())}.json" 
   
    def get_random_item(items):
        """Return a random element from a list."""
        return random.choice(items)
   
    def get_random_number(min_val, max_val):
        """Return a random integer between min_val and max_val (inclusive)."""
        return random.randint(min_val, max_val)
   
    def generate_id():
        """Generate a simple unique transaction ID (e.g. 'TX-ABCD1234')."""
        # 8 random alphanumeric characters
        random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
        return f"TX-{random_part}"
   
    def generate_random_date():
        """
        Generate a random date/time (as ISO 8601 string) between now and 30 days ago.
        """
        now = datetime.datetime.now()
        thirty_days_ago = now - datetime.timedelta(days=30)
       
        # Get a random number of seconds between thirty_days_ago and now
        total_seconds_diff = int((now - thirty_days_ago).total_seconds())
        random_offset = random.randint(0, total_seconds_diff)
       
        random_time = thirty_days_ago + datetime.timedelta(seconds=random_offset)
        return random_time.isoformat()
   
    # Generate 200 records
    record_count = 200
    transactions = []
   
    for _ in range(record_count):
        nombre = [
            "Smartphone X1000",
            "Camiseta de algodon basica",
            "Lampara LED tactil",
            "Cargador rapido UltraCharge",
            "Juego de herramientas MasterFix",
            "Zapatillas deportivas AirRun",
            "Mochila resistente AdventurePack",
            "Auriculares inalambricos SoundPro",
            "Caja organizadora FlexBox",
            "Reloj de pulsera ChronoTech"
        ]

        descripcion = [
            "Producto electronico de alta calidad, ideal para uso domestico y oficina.",
            "Camiseta de algodon suave y cómoda, disponible en varios colores.",
            "Lampara de escritorio LED con control tactil, ajustable en intensidad.",
            "Cargador rapido para dispositivos moviles, compatible con multiples marcas.",
            "Juego de herramientas para reparaciones del hogar, incluye 10 piezas.",
            "Zapatos deportivos de running, ligeros y con amortiguacion para mayor comodidad.",
            "Mochila de viaje resistente al agua, con multiples compartimentos.",
            "Audifonos inalambricos con cancelacion de ruido, duracion de bateria de hasta 20 horas.",
            "Caja de organizacion de plastico, ideal para almacenamiento en el hogar o la oficina.",
            "Reloj de pulsera con correa de acero inoxidable, diseño elegante y moderno."
        ]

        categoria = [
            "Electronica",
            "Ropa y accesorios",
            "Muebles y decoracion",
            "Herramientas y reparaciones",
            "Deportes y aire libre",
            "Juguetes y entretenimiento",
            "Alimentos y bebidas",
            "Salud y belleza",
            "Oficina y papeleria",
            "Tecnologia y gadgets"
        ]

        status = [
            "Activo",
            "Inactivo",
        ]

        # Build the transaction object
        transaction = {
            "id" : generate_id(),
            "nombre" : get_random_item(nombre),
            "descripcion" : get_random_item(descripcion),
            "categoria" : get_random_item(categoria),
            "cantidad" : get_random_number(0,100),
            "precio" : get_random_number(10,500),
            "status": get_random_item(status),
            "fecha_captura" : generate_random_date()
        }
       
        transactions.append(transaction)
   
    # Convert transactions to JSON
    data_string = json.dumps(transactions, indent=2)
   
    # Upload to S3
    s3_client = boto3.client("s3")
    try:
        s3_client.put_object(
            Bucket=bucket_name,
            Key=object_key,
            Body=data_string.encode("utf-8"),
            ContentType="application/json"
        )
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Data generated and saved to S3 successfully.",
                "location": f"s3://{bucket_name}/{object_key}"
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error saving data to S3.",
                "error": str(e)
            })
        }

